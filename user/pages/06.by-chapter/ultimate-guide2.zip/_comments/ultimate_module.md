---
title: Comments
type: comments
cssclass: white
---

<script>
	var disqus_config = function () {
	this.page.url = "http://questionsforinterviewer.com/questions-to-ask-interviewer";  // Replace PAGE_URL with your page's canonical URL variable
	this.page.identifier = "questions-to-ask-home"; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
	};

	(function() { // DON'T EDIT BELOW THIS LINE
	var d = document, s = d.createElement('script');
	s.src = 'https://questionsforinterviewer.disqus.com/embed.js';
	s.setAttribute('data-timestamp', +new Date());
	(d.head || d.body).appendChild(s);
	})();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
<span style="font-size: 12px; color: grey;">Image credits: <a href="http://www.freepik.com" target="_blank">designed by Freepik</a>.</span>