---
title: 'Please share'
type: please_share
chapter:
    heading: 'Share, comment and continue reading...'
    next: chapter-7
    number: 6
cssclass: share
---

