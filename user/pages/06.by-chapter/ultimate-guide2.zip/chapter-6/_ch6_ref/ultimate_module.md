---
title: Chapter 6 quick reference
type: quick_ref
content:
    items:
        '@taxonomy.tag': ch6_article
    order:
        by: header.article.number
---