---
title: Chapter 7 articles
type: articles
content:
    items:
        '@taxonomy.tag': ch7_article
    order:
        by: header.article.number
        dir: asc
---