---
title: Chapter header image
type: ch_header_image
cssclass: ch_header_image
chapter_number: 5
---

