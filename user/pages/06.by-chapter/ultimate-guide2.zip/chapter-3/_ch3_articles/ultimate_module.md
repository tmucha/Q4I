---
title: Chapter 3 articles
type: articles
content:
    items:
        '@taxonomy.tag': ch3_article
    order:
        by: header.article.number
        dir: asc
---