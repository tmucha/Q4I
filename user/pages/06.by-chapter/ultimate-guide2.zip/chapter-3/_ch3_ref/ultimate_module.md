---
title: Chapter 3 quick reference
type: quick_ref
content:
    items:
        '@taxonomy.tag': ch3_article
    order:
        by: header.article.number
---