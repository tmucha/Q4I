---
title: Chapter 3 heading
type: chapter_heading
chapter:
    heading: Questions about the company
    number: 3
cssclass: ch3
---
By now, you have an arsenal of questions concerning the job itself. It’s time to widen the scope and understand the company you’re applying to even better.

In this chapter, you'll continue to build on the information you’ve collected during your research and preparations for the interview. You’ll also gain more insight into information that is not directly communicated in the company's official publications.

Many of the questions about the company allow you to not only showcase your interest towards the company, but also help you figure out if this is the company where YOU want to work.

Ready to begin?