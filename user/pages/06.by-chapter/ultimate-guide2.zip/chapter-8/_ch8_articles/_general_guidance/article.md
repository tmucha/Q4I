---
background: my_grey
highlight: ch8
article:
    title: General guidelines for asking questions in a job interview
taxonomy:
    tag: ch8_article
chapter:
    number: 8
---

### GENERAL GUIDELINES FOR ASKING QUESTIONS IN A JOB INTERVIEW
It is important to prepare questions ahead of time. While it is normal that you might come up with some good questions on the fly, it is not enough to leave it all to chance.

Questions are part of your preparation for the interview. They not only help you shine as the best candidate for the job, but also enable you to interview the employer. Validating that the company and position is a good fit for you is as much of a job for the interviewer as it is for you.

Asking well-thought-out questions is the most straightforward and efficient way to dig into the company culture and the specifics of the day-to-day responsibilities on the job. Consequently, the questions help you get the job and have as smooth of a start as possible.

While most of the questions listed in the chapters above can be taken directly into use in your interview, it is perfectly fine to come up with your own questions. You can use those listed on this website as an inspiration.

In any case, it is important that you really think how the specific questions apply to the company, job and your profile. Therefore, you might want to tweak, expand or modify the questions listed here. Below you can find some further guidelines for asking good questions.

#### Ask one question at a time
Complex questions usually require complex answers. Avoid multi-part questions that require answers covering several topics at the same time. Each question should have one specific point, otherwise you will overwhelm the employer.

It is much better to say that you have several questions and ask only one at a time.

#### Avoid questions focused on yourself
Self-centered questions are those that put yourself ahead of the employer.

These questions include the following topics:
* salary
* work hours per week
* vacation time
* health insurance
* and other concessions.

During an interview, you are primarily trying to demonstrate to the employer that you can deliver value to the company and not the other way around. Only after they come back to you with the good news that they would like to hire you, can you start asking much more details about what they can offer to you.

#### Ask questions on variety of topics
Avoid asking questions about just one single subject. If you do, this subject will stand out unnaturally and draw the interviewer’s attention.

For example, if you only ask questions about the team and their collaboration style, the interviewer might assume you have an issue with teamwork.

Ask questions about a variety of topics to demonstrate your curiosity and interest in all aspects of the job and company.

#### Avoid "Yes" or "No" Questions
Remember that an interview is supposed to be a dialogue. Most “yes” or “no” questions are not conducive to real conversation.

Furthermore, questions that require only such a short answer are likely to be answered by searching other sources, such as the company’s website. Thus, asking these types of questions might indicate you haven’t done proper research before the interview.

#### Avoid personal questions
Avoid overly personal questions about the interviewer's family, race, gender, etc.

While it is definitely a good idea to try to establish rapport with your interviewer, it is better not to step into the areas that are not public information. Examples of the topics that are typically safe to venture into are travel, sports and college.