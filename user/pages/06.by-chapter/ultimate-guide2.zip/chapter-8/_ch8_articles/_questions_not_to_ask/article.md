---
background: white
highlight: ch8
article:
    title: Questions not to ask in an interview
taxonomy:
    tag: ch8_article
chapter:
    number: 8
---

### Questions NOT to Ask at a Job Interview

Since your objective in the interview is to show how you can bring value to the company and present yourself in positive light, there are some questions that are better to be left out or, at least, rephrased.

Below is list of some of the common ones.

#### What does your company do?
This is obviously the question you should have the answer to before you go to the interview. In-depth reading of the company's website is a no-brainer.

If you ask this question, you clearly demonstrate you haven't done your research and suggest that you are not really interested in the job or company.

In some cases, the company might have limited information on their website, and even a thorough research leaves some question marks. In that case, you can ask a question about what the company does, if the interviewers haven't given you a good enough overview.

#### How long do I have to wait to get promoted?
This question not only puts your interest above that of the employer, but it also indicates that you are not so interested in the position that is currently offered. The picture you are giving is that you are hoping to move on quickly to do something better.

There are more positive ways to phrase this question. For example, "<span class="contents-link" onclick="window.location.href ='/questions-to-ask-interviewer/chapter-2#article5'">(Q# 5) What are the prospects for growth for the person in this job?</span>". When you approach it in this way, you immediately show your ambition from a good perspective.

#### How many hours will I be expected to work every day? Will I need to work on weekends?
Direct questions about working hours suggest that you are not hard-working and are looking for a place where short days are common.

An alternative way to ask about the working hours is to ask about typical day and toughest time. Good examples of such questions are:
* <span class="contents-link" onclick="window.location.href ='/questions-to-ask-interviewer/chapter-2#article10'">(Q# 10) What is a typical (day, week, month, or year) for a person in this job?</span>
* <span class="contents-link" onclick="window.location.href ='/questions-to-ask-interviewer/chapter-2#article11'">(Q# 11) What is the toughest time of (day, week, month, or year) for a person in the job? Why?</span>

#### What is the salary for this position?
Unless explicitly asked by the interviewers, it is best to leave questions about the compensation for later. This is especially the case, if this is just the first interview in the process.

The best time to discuss compensation is when you are already offered a position. One clear exception is when you know beforehand that you would not take job that pays less than certain amount. If this is the case, you could state it in your cover letter (I wouldn't recommend that for entry level positions).

#### Did I get the job?
Most hiring decision require at least some consultation within the company. It is unlikely that the interviewer is ready to answer such a question straight in the interview.

Besides, this question makes you seem very impatient.

Two approaches that I'd suggest are to investigate if the interviewer has any hesitations about you and ask about the next steps in the hiring process. You can find questions that fall into these categories in <span class="contents-link" onclick="window.location.href ='/questions-to-ask-interviewer/chapter-4'">Chapter 4: Questions about the requirements</span> and <span class="contents-link" onclick="window.location.href ='/questions-to-ask-interviewer/chapter-7'">Chapter 7: Questions about the next steps</span>.

#### When can I take time off for vacation?
Remember, your job at the interview is to show that you can create value for the employer. Asking about time off for vacation is rather premature at the interview stage. It also leaves the impression that you are not very committed.

First, focus on showing that you are the best candidate for the job. Later, you can agree on the details related to time off.

If you do have some plans or commitments in the near future, you can ask a better phrased question. For example, "<span class="contents-link" onclick="window.location.href ='/questions-to-ask-interviewer/chapter-7#article54'">(Q# 54) When do you anticipate the person in this job will start work?</span>"

#### What type of health insurance does this company offer?
Again, asking about benefits is not the best starting point. Instead, you should be focusing on showing that you will create value for the company and are the best candidate for the job.

Health insurance and, potentially, any other benefits fall more into the discussion once you're offered the job.

You might ask, for example "<span class="contents-link" onclick="window.location.href ='/questions-to-ask-interviewer/chapter-6#article36'">(Q# 36) Can you tell me what you love most about working here?</span>". While the answer to this question is unlikely to consist of a list of benefits and perks from the job, it might include some.