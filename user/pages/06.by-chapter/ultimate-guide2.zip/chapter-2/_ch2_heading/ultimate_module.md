---
title: Chapter 2 heading
type: chapter_heading
chapter:
    heading: 'Questions about the job'
    number: 2
cssclass: ch2
---
The first section covered why to ask questions in a job interview. That's a fantastic first step, if you have a good and clear motivation to ask questions in your interview. This alone can already take you far, as you can come up with some good questions on the fly. 

Now I’m going to crank it up a level by adding ideas for questions covering the job itself.

Since we’re talking about JOB interviews, there is no more natural way to start a real conversation with your interviewer than by talking about the job.

So to make sure you have what it takes, this chapter offers over a dozen job-focused ideas for questions to ask in an interview. Many of these should be ready for your use directly, as they are presented below.