---
title: Chapter 2 articles
type: articles
content:
    items:
        '@taxonomy.tag': ch2_article
    order:
        by: header.article.number
        dir: asc
---