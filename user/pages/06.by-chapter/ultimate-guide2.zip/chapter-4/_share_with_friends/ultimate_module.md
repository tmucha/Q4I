---
title: 'Please share'
type: please_share
chapter:
    heading: 'Share, comment and continue reading...'
    next: chapter-5
    number: 4
cssclass: share
---

