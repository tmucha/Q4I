---
background: white
highlight: ch1
article:
    title: 'Erin Kennedy'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### Erin Kennedy
#### Why job candidates should ask questions in a job interview?
It’s always smart to go to interview with questions of your own. Why? For a number of reasons, namely it shows your preparedness and knowledge of the company. Without these two you are unlikely to stand out, at least in the positive sense. If you really want to get the job, you must invest time into preparations. 

Asking questions shows that you did your homework - you know what the company does, what they are looking for in the position, and what you will be doing. Having clear questions in mind allows you to have a real two-way conversation during the interview. Otherwise, you run the risk of spending most of the time talking about high-level topics, which will not leave a trace in the interviewer’s memory.

### Why follow Erin:
Erin Kennedy, MCD, CMRW, CERW, CEMC, CPRW is a Certified Master & Executive Resume Writer/Career Consultant, and the President of [Professional Resume Services, Inc.](http://exclusive-executive-resumes.com?target=_blank), home to some of the best resume writers on the planet.

She is a nationally published writer and contributor of 16+ best-selling career books and has written hundreds of career-related articles. Erin is a member of the [Forbes Coaches Council](https://forbescoachescouncil.com/). Professional Resume Services was voted as one of “Forbes Top 100 Career Websites”. 

Erin's Twitter handle is [@ErinKennedyCPRW](http://twitter.com/ErinKennedyCPRW?target=_blank).