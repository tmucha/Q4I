---
background: white
highlight: ch1
article:
    title: 'Karalyn Brown'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### Karalyn Brown<a id="Australia"></a>
#### Why job candidates should ask questions in a job interview?
You need to ask questions as this shows the interviewer that you are interested in the role. One thing employers hire on is your fit with their culture. Great questions show that you have done your homework and are keen to see where you can fit in and add value.

Interviews are a two way process. 

Just as an employer is assessing you as a candidate, you need to be assessing the company, and whether you have the capability to perform the role. If the role description is unclear, or it is a newly created role, questions can help you clarify the expectations an employer will have of you - and make the difference between success and failure.

If there are many suitable candidates for a role, the quality of your research and your questions may be the thing that points to you as the perfect candidate.

### Why follow Karalyn:
Karalyn Brown is the Founder of [InterviewIQ](http://interviewiq.com.au/meet-team-iq?target=_blank), a consultancy in Australia helping people find jobs.

She is a social media influencer, engaging people on topics around careers, people, HR and management. She has written for the Australian, the Sydney Morning Herald, CareerOne, Management Today, Recruiter Daily, Recruitment Extra and HR Leader. Karalyn has featured on Sky News in The Daily Telegraph, The Age, Anthill Online, Voyeur Magazine, and Latte Magazine. She has also co-authored a book: “What do employers really want?” and regularly talks jobs and how to find one on abc radio.

Karalyn's Twitter handle is [@InterviewIQ](http://twitter.com/InterviewIQ?target=_blank).