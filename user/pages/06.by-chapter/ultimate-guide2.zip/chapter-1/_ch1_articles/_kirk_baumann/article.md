---
background: my_grey
highlight: ch1
article:
    title: 'Kirk Baumann'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### Kirk Baumann
#### Why job candidates should ask questions in a job interview?
Asking questions shows curiosity and interest.

Do your research on the company and the challenges they face. That will help inform the types of questions you can ask the interviewer.

Some basic questions I would recommend would simply be things like "what do you like most about working here?" or "what is your one piece of advice you give to new hires to help them succeed?"

At the end of the interview the last question should be, "how and when should I follow up with you?" This helps you understand the best method of communication and a basic timeline for when to follow up.

### Why follow Kirk:
Kirk Baumann is a passionate recruiting advocate preparing the next generation of talent for the career of their dreams. He’s a social media enthusiast who loves technology and how it’s connecting people in ways like never before.

Kirk currently serves as Vice President, Career Services & Alumni Engagement for Enactus United States (formerly known as SIFE), working with Fortune 500 & 100 companies, helping them recruit top talent for their organizations as well as working directly with students, alumni, and young professionals on career development, helping them find their dream job. 

His blog, [Campus to Career](https://campus-to-career.com?target=_blank), is dedicated to job seekers of all kinds, with a particular focus on college students and preparation for their career after graduation.

Kirk's Twitter handle is [@kbaumann](https://twitter.com/kbaumann?target=_blank).