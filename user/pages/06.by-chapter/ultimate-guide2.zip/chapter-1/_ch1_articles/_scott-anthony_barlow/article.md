---
background: white
highlight: ch1
article:
    title: 'Scott Anthony Barlow'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### Scott Anthony Barlow
#### Why job candidates should ask questions in a job interview?
You shouldn’t – at least not for the reason you think you should.

Although it may indicate engagement and interest in the company or people that you’re potentially working with, that’s not the biggest reason why you should ask questions. A much bigger reason would be the opportunity to learn more about the organization and the people you would be working with to ultimately decide for yourself whether or not it would be a good fit for YOU.

You should leverage the opportunity to ask questions not just at the end, but throughout the entire time you’re interacting and even outside of the interview.  You can even contact other people in the organization. Come up with your own set of interview questions to determine whether or not they actually match up with what you want and need in a role and in an organization.

### Why follow Scott:
Scott Anthony Barlow is the Founder and CEO of [Happen to Your Career](http://www.happentoyourcareer.com?target=_blank). His team produces two of the Top 5 “Career Change” podcasts on iTunes: [What Fits You?](http://www.happentoyourcareer.com/what-fits-you-podcast?target=_blank) and the [Happen to Your Career Podcast](http://www.happentoyourcareer.com/category/podcast?target=_blank).

He gets way excited about careers, coffee, and Parkour (not necessarily in that order). With over 2000 interviews under his belt as a former HR professional, Scott’s gift is quickly getting to the core of what is holding career-changers back and helping others find their unique Signature Strengths! See also: [http://www.happentoyourcareer.com/team](http://www.happentoyourcareer.com/team?target=_blank)

Scott's Twitter handle is [@ScottABarlow](http://twitter.com/ScottABarlow?target=_blank). You can also find him on [Facebook](https://www.facebook.com/happentoyourcareer?target=_blank) and [LinkedIn](https://www.linkedin.com/in/scottabarlow?target=_blank).