---
background: white
highlight: ch1
article:
    title: 'Margaret Buj'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### Margaret Buj<a id="Europe"></a>
#### Why job candidates should ask questions in a job interview?
A lot of candidates don't ask any good questions. Often people feel that the job has already been explained to them and they understand the requirements, therefore they have no further questions. This lack of questions, unfortunately, leads to several issues.

To hiring managers the candidate just doesn't seem to be interested enough in the job. Furthermore, even though the candidate might understand the job, he or she still does not fully understand the specific expectations of the manager. Consequently, job seekers who fail to ask questions in their job interview typically end up not getting the job.

Depending on what has already been discussed during the interview, it is important to ask about expectations, priorities and any special projects or assignments. Besides that I always recommend that people research the companies beyond what is covered on their websites. Whenever the candidate finds something personally interesting about the organization, it is important to ask about that during the interview.

### Why follow Margaret:
Margaret Buj is a career and interview coach who specializes in helping professionals to get hired, promoted and paid more. She has 12 years of experience of recruiting for global technology and eCommerce companies across Europe & the US, and in the last 11 years, she's successfully coached hundreds of people to get the jobs and promotions they really wanted.

Recognized as one of [LinkedIn UK's Power Profiles in HR](https://lists.linkedin.com/power-profiles/uk/industry/hr?target=_blank), and with an award-winning [blog](http://www.interview-coach.co.uk/blog?target=_blank), she's spoken at career events & conferences and has done training sessions or workshops in London, Monaco, Athens & Saudi Arabia.

She's also been featured in Cosmopolitan magazine, interviewed for The Financial Times and Management Today, has written "[Land that Job](http://www.landthatjob.co.uk?target=_blank)" e-Guide. Find out more and get her free interview resources at [www.interview-coach.co.uk](https://interview-coach.co.uk/?target=_blank)

Margaret's Twitter handle is [@MargaretBuj](https://twitter.com/MargaretBuj?target=_blank). You can also connect with Margaret on [LinkedIn](http://uk.linkedin.com/in/margaretbuj?target=_blank).