---
background: my_grey
highlight: ch1
article:
    title: 'David Shindler'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### David Shindler
#### Why job candidates should ask questions in a job interview?
The job interview is a two-way street. Too many candidates fall into a fixed mindset that says, ‘I don’t want to make a mistake’. It puts you on the back foot and it feels like an ordeal. Instead, stand out by adopting a growth mindset that says, ‘I’m checking you out too, because I want to know if you’re right for me’. Get on the front foot and it will feel like an opportunity.
 
By asking questions you are no longer the center of attention, so it helps to take the pressure off. You show your listening skills if you pick up on what the interviewer says, reflect back, or summarize. Ask probing questions to dig beneath the surface of an issue. Closed questions (like ‘Do you…’ or ‘Is it…’) are useful when seeking a yes or no answer for clarification or to establish a fact. Open questions (like ‘What…’ and ‘How…’) usually prompt more information from the interviewer than intended.
 
Ask yourself what impression you want to leave. Then ask questions that shape that impression. The type of questions you ask reveal a lot to an interviewer. For example, hypothetical questions (like ‘What would happen if…’) can show off your analytical thinking or creativity. Show your initiative and interest in the company by revealing your knowledge about them in the question you ask. For example, ‘I see that you won an award for Best Customer Service this year. What do you expect from employees here?’
 
You have a golden opportunity at the end to make an impact when the interviewer asks, “Do you have any questions for us?” You can rescue an average interview or find out something to help you decide if this employer is the right one for you. Ask ‘Is there anything else you want from me to help you make a decision?’ It gives you a second chance to ensure they understood your answers, expand upon them, or to add something you meant to say but forgot.
 
Asking questions and listening well help you build rapport with the interviewer. And that’s critical because people hire people they like and who show their capabilities. Do them well and you’ll leave a great impression.

### Why follow David:
David Shindler is a career coach at [www.learningtoleap.co.uk](http://www.learningtoleap.co.uk?target=_blank) and an [online educator](https://learning-to-leap.thinkific.com?target=_blank). He is also an author of [Learning to Leap: a Guide to Being More Employable](http://amzn.to/2ynrsxg?target=_blank).

David has worked across the private, public and non-profit sectors for nearly 40 years. Prior to setting up as an independent coach in 2009, he spent over a decade in consultancy helping individuals, teams and organisations with their people development. David is also a non-executive Director of [Youth Employment UK](http://www.youthemployment.org.uk?target=_blank), a social enterprise dedicated to tackling youth unemployment and a platform for the voice of young people. I am also a member of the Institute of Employability Professionals.

Keen blogger and social collaborator - informing and empowering others: Guardian Careers top 10 on Twitter for career advice, top 25 YouTern careers blogger; BBC Radio interviews; articles in Forbes, MSN via CareerBuilderUK, CareersinGovernment and much more.

David's Twitter handle is [@David_Shindler](http://twitter.com/David_Shindler?target=_blank).