---
background: white
highlight: ch1
article:
    title: 'Ed Han'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### Ed Han
#### Why job candidates should ask questions in a job interview?
You should always ask questions in an interview! There are several reasons to do that. Here are the top three:
1. You want to make sure you understand the position and how you're faring;
2. it demonstrates your interest and gives you an opportunity to showcase research conducted about the employer and interviewer(s);
3. it’s your chance to learn the organization's or team's culture.

Asking questions in an interview is a win-win for you and the employer. You get to understand better if this is the company where you want to work and the job that you want to have. The employer gains better insight into your thinking and can picture you in the new role better.

### Why follow Ed:
Ed is positive, engaging and tech-savvy recruiter with knack for connecting the dots for culture as well as skill fit. Whether using behavioral techniques, clearly communicating requirements or understanding hiring manager preferences, he is passionate about candidate experience and best practices. His diverse experience in regulated environments such as financial services and international import helps Ed connect in an authentic, powerful way with people of all demographics.

These days Ed wears two hats. By day he is a recruiter who finds and engages A list candidates for his clients on a perm or contract basis. By night, he is a wordsmith distilling years of experience with LinkedIn for various sites, including [Job-Hunt.org](http://Job-Hunt.org?target=_blank) and [The Balance](https://www.thebalance.com?target=_blank). But no matter what time of day, he is a job seeker ally.

Ed's Twitter handle is [@ed_han](http://twitter.com/ed_han?target=_blank). You can also find him on [LinkedIn](https://www.linkedin.com/in/edmhan?target=_blank) and [Google+](https://plus.google.com/u/0/+EdHan?target=_blank).