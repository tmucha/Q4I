---
background: white
highlight: ch1
article:
    title: 'Joseph Liu'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### Joseph Liu
#### Why job candidates should ask questions in a job interview?
When you ask the right questions in an interview, it allows you to: 

1. Gather useful information. When your interviewer asks you if you have any questions, it provides you with a unique, rare opportunity to get some personal, inside perspectives from someone who's working at the organization you're considering. Beyond the interview serving as a screening mechanism for a company, an interview gives you as a candidate access to someone within the company, something you wouldn't normally have.  So don't miss out on this opportunity to get some concrete information you can't get by looking at a company website or public materials. 
2. Demonstrate you've done your homework on the organization. You can tell a lot about candidates by the type of questions they ask, so asking the right ones allows you to separate yourself from unprepared candidates who inquire about information that's publicly available. So focus on asking questions that could only be answered by people who have spent time working at the company. "What's one of the misconceptions you feel candidates have about working here?" 
3. Make a positive impression. Asking good questions also signals what factors matter to you as a candidate evaluating the opportunity at hand. This gives you an opportunity to differentiate yourself as a candidate interested in understanding what it takes to make a valuable contribution to the company. So avoid asking questions about what's in it for you (salary, hours, benefits), and instead focus on getting information that conveys a genuine interest in understanding what it takes to contribute. For example, "What are the common characteristics you observe in the people who have the greatest impact here?"

### Why follow Joseph:
[Joseph Liu](https://josephpliu.com?target=_blank) is a career consultant and a host of the [Career Relaunch Podcast](https://careerrelaunch.net?target=_blank).

Joseph Liu's mission is to help inspire people to bravely pursue more meaningful work. As a career consultant, keynote speaker, and host of the Career Relaunch podcast, he helps professionals gain the clarity, confidence, and courage to relaunch their careers.

His work is informed by 10 years of global, client-side marketing experience in the US & UK, his involvement with four major brand relaunches, and 500+ hours of professional career coaching.

He now applies principles used to build & relaunch consumer brands to help professionals and business owners build & relaunch their personal brands. He loves connecting with people at career crossroads who embrace the idea of doing work that truly matters to them and to others.

Joseph's Twitter handle is [@josephpliu](http://twitter.com/josephpliu?target=_blank). You can also follow him on [LinkedIn](http://linkedin.com/in/JosephPLiu?target=_blank), [Facebook](http://facebook.com/JosephLiuCo?target=_blank), [Instagram](http://instagram.com/CareerRelaunch?target=_blank) or [YouTube](https://www.youtube.com/c/JosephPLiu?sub_confirmation=1?target=_blank).