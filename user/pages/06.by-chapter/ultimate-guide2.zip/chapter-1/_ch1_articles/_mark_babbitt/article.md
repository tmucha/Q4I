---
background: my_grey
highlight: ch1
article:
    title: 'Mark S. Babbitt'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### Mark S. Babbitt<a id="USA"></a>
#### Why job candidates should ask questions in a job interview?
Sure, asking questions at the end of your job interview shows you’ve done your homework. The best questions also show you’re engaged in the conversation and well-versed in the industry. Asked properly, they also show a certain amount of poise and confidence. But those aren’t the best reasons for asking well-constructed questions during your job interview.

The best reason: To show you’re more concerned about “we” than “me.”

At that critical point when you’re asked “Do you have any questions for me?” take the opportunity to inquire more about the team dynamics – and specifically your fit within the current operations.

What can you do to make an immediate impact on the team and our mission? What challenges does the team currently face and how can you best help? What is the current level of mentorship available, and how can you help foster a mentor-driven sub-culture within the team?

Let your competition ask the “me” questions about salary, advancement, vacation time and doggy day care. You stay focused on “we” – and win the interview.

### Why follow Mark:
Mark is the CEO and Founder of [YouTern](http://www.youtern.com?target=_blank), a social resource for young professionals that Mashable calls a "Top 5 Online Community for Starting Your Career." 
 
Mark is also co-author of the best-seller [A World Gone Social: How Companies Must Adapt to Survive](http://amzn.to/2xCecb8?target=_blank). A prolific blogger; Mark’s work can be seen in Entrepreneur, Forbes, Harvard Business Review and many other outlets. An in-demand speaker, he was named one of Inc. Magazines Top 100 Leadership Speakers. 

Mark is the father of five, grandfather of 4, and dog-dad to two black Labradors. He and the woman who tolerates him (barely) call the mountains of Colorado home.

Mark's Twitter handle is [@MarkSBabbitt](https://twitter.com/MarkSBabbitt?target=_blank).