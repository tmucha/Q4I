---
background: my_grey
highlight: ch1
article:
    title: 'Susan P. Joyce'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### Susan P. Joyce
#### Why job candidates should ask questions in a job interview?
Typically, a job seeker with no questions is assumed to be either not interested in the job or not very bright. Employers aren't interested in a candidate who isn't really interested in them or the opportunity.

Specifically, asking your own questions will:
1. Leave a positive and memorable impression on the interviewers, particularly important if many candidates are being interviewed and you are one of the first interviewees.
2. Demonstrate your interest in the employer and the opportunity, preferably by referencing something you found in your research (e.g., a new product recently announced, a location, a competitor's name.
3. Help you gain information you want or need to decide if the job and the employer are a good fit for you.
4. Assist in diverting the interviewer's attention in uncomfortable situations (like after you have answered why you were fired from your last job).
5. Turn the interview into more of a conversation than a grilling (wth you on the hotspot).

Generally, asking good questions shows that you are both interested and prepared, which will impress the interviewer, and the answers to those questions should also help you decide whether or not you want to work for that employer.

### Why follow Susan:
Susan P. Joyce is an online job search, reputation, and personal SEO expert.

After being laid off in 1994, Susan P. Joyce began studying, writing, teaching, and speaking about the field of online job search with a focus on smart and effective job search techniques, building on her experience in military intelligence, Human Resources, and information technology. Both of Susan's websites, [Job-Hunt.org](https://www.job-hunt.org?target=_blank) (don't forget that hyphen) and Susan's blog [WorkCoachCafe.com](http://www.workcoachcafe.com?target=_blank), were selected for the Forbes Top 100 Websites for Your Career!

Affiliated with the Massachusetts Institute of Technology (MIT) Sloan School of Management from 2011 through 2016, Susan held Visiting Scholar appointments with the Sloan School since 2013.

Susan has been quoted in hundreds of articles, books, and Websites including TIME, FORTUNE, Business Week, The Wall Street Journal, The Boston Globe, The New York Times, The Los Angeles Times, and many others. Her contribution to this chapter is also a quote (used with permission) from her article titled "[45+ Good Questions to Ask in Your Job Interview](https://www.job-hunt.org/onlinejobsearchguide/article_job_interview_questions.shtml?target=_blank)". 

Susan's Twitter handles are [@JobHuntOrg](https://twitter.com/JobHuntOrg?target=_blank) and [@WorkCoachCafe](https://twitter.com/WorkCoachCafe?target=_blank).