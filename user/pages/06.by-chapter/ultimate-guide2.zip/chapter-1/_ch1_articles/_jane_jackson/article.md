---
background: my_grey
highlight: ch1
article:
    title: 'Jane Jackson'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### Jane Jackson
#### Why job candidates should ask questions in a job interview?
Having coached thousands of career transition clients over the past 17 years, a common question I'm asked is whether it is appropriate to ask questions during a job interview. I have found that asking questions during a job interview will help a candidate to stand out from the crowd.

When attending a job interview, all candidates will answer the questions posed to them, however, not all candidates will ask questions of the interviewer. This could be due to a lack of preparation, nerves, or simply a lack of interest in the role.

As a candidate in a job interview, it is essential to demonstrate a keen interest in the role, the company, and the people with whom you may work with.  This interest can be conveyed in the way that you respond to behavioural questions, the enthusiasm and passion that you exude, your body language and tone of voice.

In order to make an even greater impression during the interview, the questions you ask will help to demonstrate your understanding of the role, the confidence you have in yourself by asking for clarification where necessary, and also that you are capable of projecting yourself into the role. By asking questions the interviewer will know that you are willing to learn, keen to understand the specific requirements of the job and are interested.

During my time as a recruiter, candidates who showed initiative and could think on their feet always impressed me. Employers hire not only for skills and knowledge but also for potential. A curious and interested employee is one who usually is more productive and motivated.

So, ask questions in interviews! Find out all you need to know so that you can make an informed decision about the position. You may find that once your questions are answered, that the role is not the best fit for you or you may have found your dream role!

### Why follow Jane:
[Jane Jackson](http://www.janejacksoncoach.com?target=_blank). is a Career Management Coach, LinkedIn Specialist, Author of #1 Amazon Australia bestseller, [Navigating Career Crossroads](http://amzn.to/2wTUisI?target=_blank) and Host of ['Your Career' Podcast on iTunes](http://www.janejacksoncoach.com/podcast?target=_blank).

Her work has been featured in international media including: Sky Business News, The Huffington Post, Sydney Morning Herald, Australian Women's Weekly, CareerOne, Michael Page, Cosmopolitan Middle East, Radio 2UE, Hope Radio 103.2fm.

Jane's clients include: The Reserve Bank of Australia, Credit Suisse, The Intercontinental Hotels Group, Local Government New South Wales, Westpac Bank, Australian Graduate School of Management, University of Singapore, Port Jackson Partners, Sparke Helmore Lawyers.

Jane's Twitter handle is [@janecareercoach](https://twitter.com/janecareercoach?target=_blank). You can also follow her on [Facebook](http://www.facebook.com/janecareercoach?target=_blank) and [Instagram](http://www.instagram.com/janecareercoach?target=_blank).