---
background: my_grey
highlight: ch1
article:
    title: 'Heini Hult-Miekkavaara'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### Heini Hult-Miekkavaara
#### Why job candidates should ask questions in a job interview?
The core of a job interview is to gain a shared understanding of what is expected and possible to be achieved in the role being offered. This is as much of a responsibility of the interviewer as it is of the interviewee.

This ultimately is often only possible thanks to communication and dialogue between the employer and the potential employee.

You can consider yourself doing a favor for the company! By posing questions you can also clarify your competence and ambitions for the role not only to the interviewer, but also to yourself. Questions lead to answers.

### Why follow Heini:
Heini is a career coach and an entrepreneur.

As a career coach at [The Finnish Business School Graduates](https://www.ekonomit.fi/web/en?target=_blank), a professional organization for graduates and students in economics and business administration with over 50 000 members, Heini helps her customers clarify their talent, professional profiles and career goals. As a founder and an organizational coach at [Rahje](http://www.rahje.fi?target=_blank), she helps people in organizations to redesign them to be elastic and resilient. Heini combines these two by helping organizations’ strategic competence needs and individuals' career dreams meet. On top of that Heini is also a co-founder and a board member of [Career Counsellors and Coaches in Finland](https://uraohjaajat.net?target=_blank).

Heini is especially interested in how individuals and organizations can manage and accumulate competence when working in networked, decentralized ecosystems.

Heini's Twitter handle is [@heinihm](https://twitter.com/heinihm?target=_blank).