---
background: white
highlight: ch6
article:
    title: 'I’ve read about the company’s founding, but can you tell me more about XXX?'
    number: 38
taxonomy:
    tag: ch6_article
chapter:
    number: 6
---
Understanding the history of a company is often important, as it often defines some of the core values of the company. Therefore, this question is a good starter for the discussion about the company's culture.

#### The Company Culture
Culture is not easy to understand or grasp without being really exposed to it, but as a job seeker it is important to try to get at least some glimpse of it. By discussing important events from the company history, you can get insights into how they shaped the company's identity.

What makes things even more complex is the fact that culture can also evolve over time. Therefore, the meaning and interpretation of an event, such as company founding, can change over the years. You should be able to get some understanding of the interviewer's attitude towards the early days of the company from the tone and words that are used.

#### Showing Off Your Research in a Smart Way
Another important point about this question is that it shows you did real background research. What's more, you have a specific question and demonstrate interest.

Of course, the meaning of this question varies a lot depending on the age and status of the company you are applying to. This question (with the right and well-targeted ending) might be super relevant for a start-up or an early stage company. For example, if the company founders don't seem to be present in the business based on the information you have, you can ask for more information about them.

For more established and, especially, very mature and large companies this question might be less relevant, unless there is some really interesting fact that you can refer to. Even for such company, it can still be informative to ask such question.

#### More Ideas on How to Customize This Question
There is a lot more ways to approach this question. Here are some ideas on how to modify it:
* Ask for the link between the founding event and the current business activity, if they are quite different
* Ask about the current role of the company founders, if the business is not too mature
* Ask about how the company overcame some major crisis in more recent past, if you are aware that there was some economic downturn or clear period of struggle for the company

Many other alternatives are possible. Keep it relevant, truly interesting for you and tailored to the company status and situation.