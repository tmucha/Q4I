---
title: Chapter 6 articles
type: articles
content:
    items:
        '@taxonomy.tag': ch6_article
    order:
        by: header.article.number
        dir: asc
---