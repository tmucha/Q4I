---
background: my_grey
highlight: ch1
article:
    title: 'Mac Prichard'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### Mac Prichard
#### Why job candidates should ask questions in a job interview?
Asking your own questions in a job interview is important for five reasons.

First, it shows you’ve done your homework. Don’t be shy. Use your questions to show off the research you’ve done before the meeting. I love it when a candidate pulls out questions and notes.

Second, it shares your excitement about the job. It’s one thing to tell an employer, “I’m passionate about this opportunity.” It’s another thing to show them by asking thoughtful, probing questions.

Third, questions give you a chance to talk about your strengths. It’s okay to ask a leading question if it provides information about a topic the interviewer hasn’t raised yet.

Fourth, asking questions helps you learn more about the position, the employer, and what your life might look like if you get the job.

And finally, asking questions gives you the facts you need about the hiring process. There’s no reason you should be in the dark about what happens after the interview. Ask now so you don’t wonder later on!

### Why follow Mac:
Mac Prichard is the founder and publisher of [Mac's List](https://www.macslist.org?target=_blank), an online community for job seekers. He's also author of the job search guidebook [Land Your Dream Job Anywhere](https://www.macslist.org/land-dream-job-anywhere?target=_blank), and host of the Find Your Dream Job podcast. Learn more and get the latest podcasts by signing up at [macslist.org/podcast](http://macslist.org/podcast?target=_blank).

Mac's Twitter handle is [@Mac_Prichard](https://twitter.com/Mac_Prichard?target=_blank). You can also follow Mac's List on [Twitter](https://twitter.com/Macs_List?target=_blank) and [Facebook](https://www.facebook.com/macslist?target=_blank).