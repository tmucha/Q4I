---
background: my_grey
highlight: ch1
article:
    title: 'Hannah Morgan'
    expert: true
taxonomy:
    tag: ch1_article
chapter:
    number: 1
process:
    twig: true
---
### Hannah Morgan
#### Why job candidates should ask questions in a job interview?

The interview is a fact-finding mission! NOT an interrogation.

Conduct thorough research on the company to help you determine the answers you are looking for. In other words, what is most important to you in a job, company, manager and co-workers. During an interview, ask open-ended, non-leading questions to get the best answers, and add specific company questions as well.

By asking these open-ended questions, you allow the interviewer to speak about the issues that are most important to them- right now. Listen carefully to which path they chose to take as they answer. You may think you know the answers, but the interviewer might have a different logic.

Asking questions shows interest, that’s a good thing. Having these pre-written questions with you during the interview will remind you of what you are supposed to be asking. (Yes, you can bring a list of questions! The interviewer is reading off a list so why can’t you?) Those endorphins have a way of stealing your brain power and you may have difficulty remembering everything you wanted to ask.

The idea is to have a dialog with your interviewer. The flow should go something like this: They ask you a question. You provide an answer and ask them a question. A nice tennis match feel.

However, if the interview is inexperienced this can be quite challenging. They may do all the talking as a result of their insecurity. Listen dutifully. Be careful not to threaten their egos by interrupting too often.

### Why follow Hannah:
A nationally recognized author and speaker on all things job search, Hannah Morgan educates from experience, research and embedding herself in what’s trending in the career industry.

Hannah founded [Career Sherpa](http://careersherpa.net?target=_blank) which blended her career expertise with her love of writing, speaking and social media. Her mission is to educate professionals through her articles (in fact, the section above is a quote from her [article](http://careersherpa.net/interviewing-is-a-fact-finding-mission-not-an-interrogation?target=_blank) - used with permission) and presentations about how to maneuver through the often treacherous job search process. Her sage advice has since been featured in Huffington Post, Business Insider, Fast Company, Forbes, AOL Jobs, The Muse, Monster, USA Today, Yahoo Finance and Money magazine.

Despite considering herself as an “unapologetic introvert”, Hannah has become an example of an online influencer. With a Twitter following of over 41,000, [@careersherpa](https://twitter.com/careersherpa?target=_blank) is recognized in the social media job search arena as a top resource for job search. She is highlighted as a Top Influencer in lists published by The Daily Muse, Job Search Bible, YouTern, Campus to Career, LifeHack, LinkUp, CEO World Magazine, Forbes, and Monster.com.

Apart from Twitter, you can also connect with Hannah on [Facebook](http://www.facebook.com/careersherpa?target=_blank) and [Linkedin](http://www.linkedin.com/in/hannahmorgan?target=_blank).