---
title: Chapter 4 quick reference
type: quick_ref
content:
    items:
        '@taxonomy.tag': ch4_article
    order:
        by: header.article.number
---