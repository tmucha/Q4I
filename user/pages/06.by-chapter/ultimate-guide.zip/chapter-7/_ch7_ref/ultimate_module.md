---
title: Chapter 7 quick reference
type: quick_ref
content:
    items:
        '@taxonomy.tag': ch7_article
    order:
        by: header.article.number
---