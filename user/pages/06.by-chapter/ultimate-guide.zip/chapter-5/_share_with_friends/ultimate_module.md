---
title: 'Please share'
type: please_share
chapter:
    heading: 'Share, comment and continue reading...'
    next: chapter-6
cssclass: share
---

