---
background: white
highlight: ch8
article:
    title: Intro to how to ask questions in an interview?
taxonomy:
    tag: ch8_article
chapter:
    number: 8
---
### FIRST THINGS FIRST
First of all, use your own brain and common sense. No two companies are alike and no two interviews are exactly the same. Not to mention that you are a unique person and you have to follow your own intuition.

Now that we have the first point covered, we can move on to more actionable advice (while still keeping the first point in mind).

The rest of this chapter includes:
* General guidelines for asking questions in a job interview
* Questions NOT to ask in a job interview
* Frequently asked questions about asking questions in a job interview